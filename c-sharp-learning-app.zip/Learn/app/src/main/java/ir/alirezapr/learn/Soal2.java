package ir.alirezapr.learn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.Random;

public class Soal2 extends Activity {

    RadioButton RadioA,RadioB,RadioC,RadioD;
    TextView Javab;
    Button next;
    Intent l;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soal2);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        findViews();
        initialits();
    }

    public void peresRadioButton (View v){
        int id = v.getId();
        if (id == R.id.RadioA){
            RadioB.setChecked(false);
            RadioD.setChecked(false);
            RadioC.setChecked(false);
            checkRadset();
        }
        else if (id == R.id.RadioB){
            RadioA.setChecked(false);
            RadioD.setChecked(false);
            RadioC.setChecked(false);
            checkRadset();
        }
        else if (id == R.id.RadioC){
            RadioA.setChecked(false);
            RadioD.setChecked(false);
            RadioB.setChecked(false);
            checkRadset();
        }
        else if (id == R.id.RadioD){
            RadioA.setChecked(false);
            RadioC.setChecked(false);
            RadioB.setChecked(false);
            checkRadset();
        }
    }

    void checkRadset (){
        String value = "";
        if (RadioA.isChecked()){
            value += "جواب شما غلط است";
            next.setVisibility(View.VISIBLE);
            RadioA.setVisibility(View.INVISIBLE);
            RadioB.setVisibility(View.INVISIBLE);
            RadioC.setVisibility(View.INVISIBLE);
            RadioD.setVisibility(View.INVISIBLE);
        }
        if (RadioB.isChecked()){
            value += "جواب شما صحیح است";
            next.setVisibility(View.VISIBLE);
            RadioA.setVisibility(View.INVISIBLE);
            RadioB.setVisibility(View.INVISIBLE);
            RadioC.setVisibility(View.INVISIBLE);
            RadioD.setVisibility(View.INVISIBLE);
        }
        if (RadioC.isChecked()){
            value += "جواب شما غلط است";
            next.setVisibility(View.VISIBLE);
            RadioA.setVisibility(View.INVISIBLE);
            RadioB.setVisibility(View.INVISIBLE);
            RadioC.setVisibility(View.INVISIBLE);
            RadioD.setVisibility(View.INVISIBLE);
        }
        if (RadioD.isChecked()){
            value += "جواب شما غلط است";
            next.setVisibility(View.VISIBLE);
            RadioA.setVisibility(View.INVISIBLE);
            RadioB.setVisibility(View.INVISIBLE);
            RadioC.setVisibility(View.INVISIBLE);
            RadioD.setVisibility(View.INVISIBLE);
        }
        Javab.setText(value);
    }

    void initialits (){
        checkRadset();
    }

    void findViews (){
        Javab   = (TextView) findViewById (R.id.tvJ);
        RadioA = (RadioButton) findViewById(R.id.RadioA);
        RadioB = (RadioButton) findViewById(R.id.RadioB);
        RadioC  = (RadioButton) findViewById(R.id.RadioC);
        RadioD = (RadioButton) findViewById(R.id.RadioD);
        next   = (Button) findViewById(R.id.Bnext2);

    }
    public void Bnext2(View v){
        Random r = new Random();
        int ra = r.nextInt(3)+1;
        switch (ra) {
            case 1:
                l = new Intent(this, Soal4.class);
                startActivity(l);
                break;
            case 2:
                l = new Intent(this, Soal5.class);
                startActivity(l);
                break;
            case 3:
                l = new Intent(this, Soal6.class);
                startActivity(l);
                break;
        }
    }

    @Override
    public void onBackPressed()
    {
        l = new Intent(this,MainActivity.class);
        startActivity(l);
    }
}
