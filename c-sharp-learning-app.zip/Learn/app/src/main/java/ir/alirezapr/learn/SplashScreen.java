package ir.alirezapr.learn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;

public class SplashScreen extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);
		
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		
		new Handler().postDelayed(new Thread(){

				@Override
				public void run()
				{
					
					// TODO: Implement this method
					Intent i = new Intent(SplashScreen.this,MainActivity.class);
					startActivity(i);
					finish();
					overridePendingTransition(R.anim.abc_fade_in, R.anim.abc_fade_out);
					
				}

				
	
				
			},3500);
			

		View myView = findViewById(R.id.logopic);
// define Animation ((fade in))
		Animation fadeInP = new AlphaAnimation(0, 1);
		fadeInP.setInterpolator(new DecelerateInterpolator()); 
		fadeInP.setStartOffset(1000);
		fadeInP.setDuration(2500);
// set Animation
		myView.setVisibility(View.GONE);
		myView.setVisibility(View.VISIBLE);
		myView.setAnimation(fadeInP);
		
		
		View myView1 = findViewById(R.id.logotext);
// define Animation ((fade in))
		Animation fadeInT = new AlphaAnimation(0, 1);
		fadeInT.setInterpolator(new DecelerateInterpolator()); 
		fadeInT.setStartOffset(1300);
		fadeInT.setDuration(2300);
// set Animation
		myView1.setVisibility(View.GONE);
		myView1.setVisibility(View.VISIBLE);
		myView1.setAnimation(fadeInT);
		
		
		View myView2 = findViewById(R.id.logotext);
// define Animation ((fade in))
		Animation fadeInT2 = new AlphaAnimation(0, 1);
		fadeInT2.setInterpolator(new DecelerateInterpolator()); 
		fadeInT2.setStartOffset(1700);
		fadeInT2.setDuration(1900);
// set Animation
		myView2.setVisibility(View.GONE);
		myView2.setVisibility(View.VISIBLE);
		myView2.setAnimation(fadeInT2);
		
		
    }
}
