package ir.alirezapr.learn;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.internal.BottomNavigationMenuView;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static final int EXTERNAL_STORAGE_PERMISSION_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    private boolean sentToSettings = false;
    private SharedPreferences permissionStatus;

    private TextView tvname,tvLinkV,tvname2,aboutprog;
    private Button pdf,zip;
    ListView LV,LV2;
    Intent l;
    public void Quiz (){
        Random r = new Random();
        int ra = r.nextInt(3)+3;
        switch (ra) {
            case 3:
                l = new Intent(this,Soal1.class);
                startActivity(l);
                break;
            case 4:
                l = new Intent(this,Soal2.class);
                startActivity(l);
                break;

            case 5:
                l = new Intent(this,Soal3.class);
                startActivity(l);
                break;

        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 12234: {
                // If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //dastrasi dade shode
            }
            else {
                new AlertDialog.Builder(this)
                        .setMessage("برای اجرای برنامه باید حتما دسترسی رو به برنامه بدهید")
                        .setCancelable(false)
                        .setNegativeButton("دادن دسترسی", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface dialog, int which) {
                                setPermission();
                            }
                        }).show();
            }
            return;
            }
        }
    }
    public void setPermission(){
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 12234);
            }
            else { ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 12234);
            }
        }
    }


                @Override
                protected void onCreate(Bundle savedInstanceState) {
                    super.onCreate(savedInstanceState);
                    setContentView(R.layout.activity_main);

                    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

                    findViews();

                    my_notifi = new Notification.Builder(this);
                    my_notifi.setAutoCancel(true);

                    setPermission();                  

                    String d[] = new String[] {"فهرست آموزش ها","علاقه مندی ها","آزمون","جستجو","تنظیمات"};
                    ArrayList<String> AL = new ArrayList<String>();
                    for (int i=0;i<d.length;i++){
                        AL.add(d[i]);
                    }
                    ArrayAdapter<String> adp = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,AL);
                    LV2.setAdapter(adp);
                    LV2.setClickable(true);
                    LV2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            int a = position;
                            if (a==0){
                                l = new Intent(getApplicationContext(),tblOfContent.class);
                                startActivity(l);
                            }
                            if (a==1){
                                l = new Intent(getApplicationContext(), tblOfFavoriteLearn.class);
                                startActivity(l);
                            }
                            if (a==2){
                                Quiz();
                            }
                            if (a==3){
                                l = new Intent(getApplicationContext(),search.class);
                                startActivity(l);
                            }
                            if (a==4){
                                l = new Intent(getApplicationContext(),settings.class);
                                startActivity(l);
                            }
                        }
                    });


                    BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
                    disableShiftMode(navigation);
                    navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener(){
                        @Override
                        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                            switch (item.getItemId()) {
                                case R.id.navigation_home:
                                    LV2.setVisibility(View.VISIBLE);

                                    aboutprog.setVisibility(View.GONE);

                                    zip.setVisibility(View.GONE);

                                    tvLinkV.setVisibility(View.GONE);

                                    pdf.setVisibility(View.GONE);

                                    LV.setVisibility(View.GONE);

                                    tvname.setVisibility(View.GONE);

                                    tvname2.setVisibility(View.GONE);

                                    return true;
                                //word important
                                case R.id.navigation_grave:
                                    Toast.makeText(getApplicationContext(),"برای توضیحات بیشتر روی آیتم مورد نظر کلیک کنید...",Toast.LENGTH_LONG).show();

                                    aboutprog.setVisibility(View.GONE);

                                    LV2.setVisibility(View.GONE);

                                    zip.setVisibility(View.GONE);

                                    tvLinkV.setVisibility(View.GONE);

                                    pdf.setVisibility(View.GONE);

                                    tvname.setVisibility(View.GONE);

                                    tvname2.setVisibility(View.GONE);

                                    LV.setVisibility(View.VISIBLE);

                                    String d2[] = new String[] {"int","float","string","char","double","short","long","if()","else","else if()","while()","for()","switch(),case()","Write()","WriteLine()","ReadKey()","ReadLine()","return true","return false"};
                                    ArrayList<String> AL2 = new ArrayList<String>();
                                    for (int i=0;i<d2.length;i++){
                                        AL2.add(d2[i]);
                                    }
                                    ArrayAdapter<String> adp2 = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,AL2);
                                    LV.setAdapter(adp2);
                                    LV.setClickable(true);
                                    LV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                        @Override
                                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                            int a = position;
                                            if (a==0){
                                                Toast.makeText(getApplicationContext(),"برای ذخیره سازی متغیر از نوع عدد صحیح بزرگ استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==1){
                                                Toast.makeText(getApplicationContext(),"برای ذخیره سازی متغیر از نوع اعشاری با تعداد رقم کم استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==2){
                                                Toast.makeText(getApplicationContext(),"برای ذخیره سازی متغیر از نوع رشته یا حروف استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==3){
                                                Toast.makeText(getApplicationContext(),"برای ذخیره سازی متغیر از نوع یک کاراکتر یا یک حرف استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==4){
                                                Toast.makeText(getApplicationContext(),"برای ذخیره سازی متغیر از نوع عدد اعشاری با تعداد رقم زیاد استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==5){
                                                Toast.makeText(getApplicationContext(),"برای ذخیره سازی اعداد کوچک استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==6){
                                                Toast.makeText(getApplicationContext(),"برای ذخیره سازی  اعداد بزرگ با رقم زیاد استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==7){
                                                Toast.makeText(getApplicationContext(),"به معنی ((گر)) می باشد و برای شرط گذاری استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==8){
                                                Toast.makeText(getApplicationContext(),"به معنی ((وگرنه)) می باشد و بعد از if میاید و برای شرط گذاری استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==9){
                                                Toast.makeText(getApplicationContext(),"به معنی ((وگرنه اگر)) می باشد و بعد از if میاید و برای شرط گذاری استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==10){
                                                Toast.makeText(getApplicationContext(),"به معنی ((تکرار کن تا وقتی که)) می باشد و برای شرط گذاری استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if(a==11) {
                                                Toast.makeText(getApplicationContext(),"از این کلمه برای ساخت حلقه تکرار در صورت صحیح بودن شرایط نوشته شده در پرانتز استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==12){
                                                Toast.makeText(getApplicationContext(),"این دو کلمه با هم می آیند و برای شرط گذاری استفاده می شوند",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==13){
                                                Toast.makeText(getApplicationContext(),"برای چاپ کردن حروف و اعداد ادامه خط قبل در کنسول استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==14){
                                                Toast.makeText(getApplicationContext(),"برای چاپ کردن حروف و اعداد و پایین رفتن چشمک زن در کنسول استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==15){
                                                Toast.makeText(getApplicationContext(),"برای دریافت کردن یک کلید از طرف کاربر در کنسول استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==16){
                                                Toast.makeText(getApplicationContext(),"برای دریافت کردن یک متغیر از طرف کاربر استفاده می شود",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==17){
                                                Toast.makeText(getApplicationContext(),"در صورت استفاده از این تابع به صورت پیش فرض کدها ادامه خواهد یافت",Toast.LENGTH_LONG).show();
                                            }
                                            if (a==18){
                                                Toast.makeText(getApplicationContext(),"در صورت استفاده از این تابع،برنامه از دستور کد ها یا حلقه خارج می شود",Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                                    return true;
                                //download
                                case R.id.navigation_download:

                                    pdf.setVisibility(View.VISIBLE);
                                    pdf.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            //permission();
                                            CopyAssets();
                                            Toast.makeText(getApplicationContext(),"فابل PDF در حافظه دستگاه کپی شد...",Toast.LENGTH_LONG).show();
                                            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/csharp-book.pdf");
                                            //Open PDF
                                            Intent intent = new Intent(Intent.ACTION_VIEW);
                                            intent.setDataAndType(Uri.fromFile(file), "application/pdf");
                                            startActivity(intent);
                                        }
                                    });

                                    zip.setVisibility(View.VISIBLE);
                                    zip.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            //permission();
                                            CopyAssets2();
                                            Toast.makeText(getApplicationContext(),"فابل Zip در حافظه دستگاه کپی شد...",Toast.LENGTH_LONG).show();
                                            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/All Project.zip");
                                            //Open Zip
                                            Intent intent = new Intent(Intent.ACTION_VIEW);
                                            intent.setDataAndType(Uri.fromFile(file), "application/zip");
                                            startActivity(intent);
                                        }
                                    });

                                    tvLinkV.setVisibility(View.VISIBLE);
                                    tvLinkV.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent Download = new Intent(Intent.ACTION_VIEW, Uri.parse("http://dl1.sarzamindownload.com/sdlftpuser02/94/05/10/Visual.Studio.Enterprise_2015.rar\n"));
                                            startActivity(Download);
                                        }
                                    });

                                    LV2.setVisibility(View.GONE);

                                    aboutprog.setVisibility(View.GONE);

                                    LV.setVisibility(View.GONE);

                                    tvname.setVisibility(View.GONE);

                                    tvname2.setVisibility(View.GONE);

                                    return true;
                                //About
                                case R.id.navigation_info:

                                    alert_we1(
                                            getString(R.string.about_me_title1) ,
                                            getString(R.string.about_me_message) ,
                                            true
                                    );
                                    //Show Notification
                                    notifi();

                                    LV2.setVisibility(View.GONE);

                                    aboutprog.setVisibility(View.VISIBLE);

                                    zip.setVisibility(View.GONE);

                                    tvLinkV.setVisibility(View.GONE);

                                    pdf.setVisibility(View.GONE);

                                    LV.setVisibility(View.GONE);

                                    tvname.setVisibility(View.VISIBLE);

                                    tvname2.setVisibility(View.VISIBLE);

                                    return true;
                            }
                            return false;
                        }
                    });
                }
                //Copy az Asset
            private void CopyAssets() {
                AssetManager assetManager = getAssets();
                String[] files = null;
                try {
                    files = assetManager.list("Files");
                } catch (IOException e) {
                    Log.e("tag", e.getMessage());
                }
                for(String filename : files) {
                    System.out.println("File name => "+filename);
                    InputStream in = null;
                    OutputStream out = null;
                    try {
                        in = assetManager.open("Files/"+filename);   // if files resides inside the "Files" directory itself
                        out = new FileOutputStream(Environment.getExternalStorageDirectory().toString() +"/" + filename);
                        copyFile(in, out);
                        in.close();
                        in = null;
                        out.flush();
                        out.close();
                        out = null;
                    } catch(Exception e) {
                        Log.e("tag", e.getMessage());
                    }
                }
            }
            private void CopyAssets2() {
                AssetManager assetManager = getAssets();
                String[] files2 = null;
                try {
                    files2 = assetManager.list("Files2");
                } catch (IOException e) {
                    Log.e("tag", e.getMessage());
                }
                for(String filename : files2) {
                    System.out.println("File name => "+filename);
                    InputStream in = null;
                    OutputStream out = null;
                    try {
                        in = assetManager.open("Files2/"+filename);   // if files resides inside the "Files" directory itself
                        out = new FileOutputStream(Environment.getExternalStorageDirectory().toString() +"/" + filename);
                        copyFile(in, out);
                        in.close();
                        in = null;
                        out.flush();
                        out.close();
                        out = null;
                    } catch(Exception e) {
                        Log.e("tag", e.getMessage());
                    }
                }
            }
            //Copy File
            private void copyFile(InputStream in, OutputStream out) throws IOException {
                byte[] buffer = new byte[1024];
                int read;
                while((read = in.read(buffer)) != -1){
                    out.write(buffer, 0, read);
                }
            }

            //DisableShiftMode
            @SuppressLint("RestrictedApi")
            private void disableShiftMode(BottomNavigationView view){
                BottomNavigationMenuView menuView = (BottomNavigationMenuView) view.getChildAt(0);
                try {
                    Field shiftingMode = menuView.getClass().getDeclaredField("mShiftingMode");
                    shiftingMode.setAccessible(true);
                    shiftingMode.setBoolean(menuView , false);
                    shiftingMode.setAccessible(false);
                    for (int i = 0; i < menuView.getChildCount();i++){
                        BottomNavigationItemView item = (BottomNavigationItemView) menuView.getChildAt(i);
                        item.setShiftingMode(false);
                        item.setChecked(item.getItemData().isChecked());
                    }
                }
                catch (NoSuchFieldException e){
                    Log.e("BNVHelper","Unable to get shift mode field",e);
                }
                catch (IllegalAccessException e){
                    Log.e("BNVHelper","Unable to change value of shift mode",e);
                }
            }
            void findViews(){
                tvLinkV = (TextView) findViewById(R.id.tvLinkV);
                pdf = (Button) findViewById(R.id.Downloadpdf);
                LV = (ListView) findViewById(R.id.Lv2);
                LV2 = (ListView) findViewById(R.id.LV1);
                aboutprog = (TextView) findViewById(R.id.aboutpr);
                tvname = (TextView) findViewById(R.id.tvname);
                zip = (Button) findViewById(R.id.downloazip);
            }
            public void alert_we1( String title , String message , boolean cancelable )
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(this);
                alert.setCancelable( cancelable );
                alert.setTitle(title);
                alert.setMessage(message);
                alert.create();
                alert.show();
            }

            @Override
            public void onBackPressed()
            {
                backButtonHeandler();
                return;
            }

            public void backButtonHeandler()
            {
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                //Setting Dialog Title
                alert.setTitle("خروج");
                //Setting Dialog Massage
                alert.setMessage("آیا می خواهید از برنامه خارج شوید؟");
                //Setting Icon to Dialog
                alert.setIcon(R.drawable.closered);
                //Setting Positive "بله" Button
                alert.setPositiveButton("بله", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                });
                //Setting Negative "خیر" Button
                alert.setNegativeButton("خیر", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                //Showing Alert Message
                alert.show();
            }

            Notification.Builder my_notifi;
            public static final int a=12345;
            @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
            public void notifi() {
                my_notifi.setSmallIcon(R.drawable.site_icon);
                my_notifi.setWhen(System.currentTimeMillis());
                my_notifi.setContentTitle("از سایت ما دیدن کنید");
                my_notifi.setContentText("www.CodeDesigner.ir");
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                PendingIntent pi = PendingIntent.getActivities(getApplicationContext(), 0, new Intent[]{i}, PendingIntent.FLAG_UPDATE_CURRENT);
                my_notifi.setContentIntent(pi);
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.notify(a, my_notifi.build());
            }

    }


