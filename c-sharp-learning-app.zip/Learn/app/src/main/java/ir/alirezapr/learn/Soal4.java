package ir.alirezapr.learn;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.Random;

public class Soal4 extends AppCompatActivity {

    RadioButton radioA,radioB,radioC,radioD;
    TextView Javab;
    Button next;
    Intent l;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soal4);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        findViews();
        initialits();
    }

    public void peresRadioButton (View v){
        int id = v.getId();
        if (id == R.id.radioA){
            radioB.setChecked(false);
            radioD.setChecked(false);
            radioC.setChecked(false);
            checkRadset();
        }
        else if (id == R.id.radioB){
            radioA.setChecked(false);
            radioD.setChecked(false);
            radioC.setChecked(false);
            checkRadset();
        }
        else if (id == R.id.radioC){
            radioB.setChecked(false);
            radioD.setChecked(false);
            radioA.setChecked(false);
            checkRadset();
        }
        else if (id == R.id.radioD){
            radioB.setChecked(false);
            radioA.setChecked(false);
            radioC.setChecked(false);
            checkRadset();
        }
    }

    void checkRadset (){
        String value = "";
        if (radioA.isChecked()){
            value += "جواب شما غلط است";
            next.setVisibility(View.VISIBLE);
            radioA.setVisibility(View.INVISIBLE);
            radioB.setVisibility(View.INVISIBLE);
            radioC.setVisibility(View.INVISIBLE);
            radioD.setVisibility(View.INVISIBLE);
        }
        if (radioB.isChecked()){
            value += "جواب شما غلط است";
            next.setVisibility(View.VISIBLE);
            radioA.setVisibility(View.INVISIBLE);
            radioB.setVisibility(View.INVISIBLE);
            radioC.setVisibility(View.INVISIBLE);
            radioD.setVisibility(View.INVISIBLE);
        }
        if (radioC.isChecked()){
            value += "جواب شما غلط است";
            next.setVisibility(View.VISIBLE);
            radioA.setVisibility(View.INVISIBLE);
            radioB.setVisibility(View.INVISIBLE);
            radioC.setVisibility(View.INVISIBLE);
            radioD.setVisibility(View.INVISIBLE);
        }
        if (radioD.isChecked()){
            value += "جواب شما صحیح است";
            next.setVisibility(View.VISIBLE);
            radioA.setVisibility(View.INVISIBLE);
            radioB.setVisibility(View.INVISIBLE);
            radioC.setVisibility(View.INVISIBLE);
            radioD.setVisibility(View.INVISIBLE);
        }
        Javab.setText(value);
    }

    public void Bnext4(View v){
        Random r = new Random();
        int ra = r.nextInt(3)+1;
        switch (ra) {
            case 1:
                l = new Intent(this, Soal7.class);
                startActivity(l);
                break;
            case 2:
                l = new Intent(this, Soal8.class);
                startActivity(l);
                break;
            case 3:
                l = new Intent(this, Soal9.class);
                startActivity(l);
                break;
        }
    }

    void initialits (){
        checkRadset();
    }

    @Override
    public void onBackPressed()
    {
        l = new Intent(this,MainActivity.class);
        startActivity(l);
    }

    void findViews (){
        Javab = (TextView) findViewById(R.id.tvJ);
        radioA = (RadioButton) findViewById(R.id.radioA);
        radioB = (RadioButton) findViewById(R.id.radioB);
        radioC = (RadioButton) findViewById(R.id.radioC);
        radioD = (RadioButton) findViewById(R.id.radioD);
        next   = (Button) findViewById(R.id.Bnext4);
    }

}
